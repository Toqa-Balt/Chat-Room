import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module.js';
import { ValidationPipe } from '@nestjs/common';
import { NestExpressApplication } from '@nestjs/platform-express';
async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  app.useGlobalPipes(
    new ValidationPipe({
      transform: true,
      whitelist : true,
      forbidNonWhitelisted : true 
    })
  )


  await app.listen(3000, () => {
    console.log('Server Started on port 3000');
  });
}
bootstrap();
